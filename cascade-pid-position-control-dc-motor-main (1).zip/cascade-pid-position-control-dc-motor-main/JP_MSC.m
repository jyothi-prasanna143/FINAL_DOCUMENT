clc;
clear;
close all;

J = 0.01;
b = 0.1;
K = 0.01;
R = 1;
L = 0.5;

s = tf('s');

Gspeed = K/((J*s+b)*(L*s+R)+K^2);

Kps = 100;
Kis = 200;
Kds = 10;

Cspeed = pid(Kps,Kis,Kds);

SpeedLoop = feedback(Cspeed*Gspeed,1);

Kpp = 20;
Kip = 5;
Kdp = 1;

Cpos = pid(Kpp,Kip,Kdp);

CascadeSystem = feedback(Cpos*(SpeedLoop/s),1);

figure;
step(CascadeSystem);
grid on;

title('Cascade PID Position Control');

info = stepinfo(CascadeSystem)

disp(info)